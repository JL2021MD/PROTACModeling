Contents in this folder provide an example system to help you quickly get familiar with using this method.
To directly run from these files, Ambertools and AMBER MD (pmemd.cuda) will be required. Alternatively, pmemd.MPI will also work but will be much slower.
