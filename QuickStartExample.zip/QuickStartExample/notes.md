Contents in this folder provide an example project to help you quickly get familiar with using this method.
To directly run from these files, Ambertools and UCSF Chimera will be required. You do not yet need AMBER MD if purely running in demo mode. Going through the whole process in demo mode will only take about 15 minutes.

These are the top 5 diverse poses from 3MXF-4TZ4 ternary docking (the example). The 11_11 is the near-native one. 

The script will put each of them into seperate folders. Note the near native originally ranked no.3 from ternary docking 11_11 will be put into folder 1 because of the numerical order of reading files by bash. See more info in the ./Other/TernaryDockingScores file.
