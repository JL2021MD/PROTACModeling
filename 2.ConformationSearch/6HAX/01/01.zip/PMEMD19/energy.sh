complex_prmtop="../Tleap/complex.gas.prmtop"
bothproteins_prmtop="../Tleap/2proteins.prmtop"
VHL_prmtop="../Tleap/VHL.prmtop"
BD_prmtop="../Tleap/BD.prmtop"
BD_PROTAC="../Tleap/BD+protac.prmtop"
VHL_PROTAC="../Tleap/VHL+protac.prmtop"
protac_prmtop="../Tleap/protac.prmtop"
trajectory="2-10.BDalign.nc"

cat >mmgbsa.in<<EOF
mmgbsa VHL-BD analysis
&general                                                                                                                                   
  interval=1, netcdf=1, verbose=2
  keep_files=0, startframe=417, endframe=1000
/                                                                                                                                          
&gb
  igb=5,                                          
  saltcon=0.0, surften=0.0072,
  surfoff=0.0, molsurf=0,
/
nmode 
  drms=0.002, maxcyc=10000,
  nminterval=1, nmendframe=2000,
  nmode_igb=1,                                
/                
                                               
EOF

out="energy.results.dat"
out_frames="energy.per-frame.dat"

mpirun -np 4 MMPBSA.py.MPI -O -i mmgbsa.in \
           -o  $out \
           -eo $out_frames \
           -cp ${complex_prmtop} \
           -rp ${bothproteins_prmtop} \
           -lp ${protac_prmtop} \
            -y ${trajectory}
sed -i '1i2 PROTEINS AS RECEPTOR
' $out
sed -i '1i2 PROTEINS AS RECEPTOR
' $out_frames
rm reference.frc
mpirun -np 4 MMPBSA.py.MPI -O -i mmgbsa.in \
           -o  BD_as_lig.dat \
           -eo BD_as_lig.per-frame.dat \
           -cp ${complex_prmtop} \
           -rp ${VHL_PROTAC} \
           -lp ${BD_prmtop} \
            -y ${trajectory}
printf '\n\n\n\n\nBRD4 AS LIGAND \n' >> $out
cat BD_as_lig.dat >> $out

printf '\n\n\n\n\nBRD4 AS LIGAND \n' >> $out_frames
cat BD_as_lig.per-frame.dat >> $out_frames

rm reference.frc
mpirun -np 4 MMPBSA.py.MPI -O -i mmgbsa.in \
           -o  VHL_as_lig.dat \
           -eo VHL_as_lig.per-frame.dat \
           -cp ${complex_prmtop} \
           -rp ${BD_PROTAC} \
           -lp ${VHL_prmtop} \
            -y ${trajectory}
printf '\n\n\n\n\nVHL AS LIGAND \n' >> $out
cat VHL_as_lig.dat >> $out

printf '\n\n\n\n\nVHL AS LIGAND \n' >> $out_frames
cat VHL_as_lig.per-frame.dat >> $out_frames

rm VHL_as_lig.dat BD_as_lig.dat reference.frc VHL_as_lig.per-frame.dat BD_as_lig.per-frame.dat mmgbsa.in
